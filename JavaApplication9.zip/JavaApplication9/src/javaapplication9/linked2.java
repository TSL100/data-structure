/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication9;

public class linked2 {
    public int data;
    public linked2 next;

    public linked2(int data) {
        this.data = data;
    }
    
}
